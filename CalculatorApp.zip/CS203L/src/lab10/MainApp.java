package lab10;


import javax.swing.*;

import java.awt.*;

public class MainApp {

	public static void main(String[] args) {
		GUI gui = new GUI();
		gui.start();
	}

}

